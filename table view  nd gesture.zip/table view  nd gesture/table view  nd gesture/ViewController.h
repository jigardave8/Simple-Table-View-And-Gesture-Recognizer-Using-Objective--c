//
//  ViewController.h
//  table view  nd gesture
//
//  Created by MAC OS on 1/24/1938 Saka.
//  Copyright (c) 1938 Saka MAC OS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>

{
    NSMutableArray *arr;
    UITapGestureRecognizer *tap;
    
    
    
}

@property (weak, nonatomic) IBOutlet UITableView *tbl;

@end

