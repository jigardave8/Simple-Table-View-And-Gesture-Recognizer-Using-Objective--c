//
//  ViewController.m
//  table view  nd gesture
//
//  Created by MAC OS on 1/24/1938 Saka.
//  Copyright (c) 1938 Saka MAC OS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    UIView *v1 ;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    arr=[[NSMutableArray alloc]initWithObjects:@"coffee.jpg",@"burger.jpg",@"cake.jpg" ,nil];
    
    
    
    
    
}

-(void)handle:(UITapGestureRecognizer *)
sender
{
    
    
    NSLog(@"%ld",sender.view.tag);
    
    
    
    if (v1.tag==0) {
        
        
        [v1 removeFromSuperview];
        
    }

    
    NSInteger test1 = sender.view.tag;
    v1=[[UIView alloc]initWithFrame:CGRectMake(0,2*test1*40, 200, 100)];
    v1.backgroundColor=[UIColor blueColor];
    
    v1.tag=0;
    UIImageView *img1 =[[UIImageView alloc]initWithFrame:v1.bounds];
    

    
    img1.image=[UIImage imageNamed:[arr objectAtIndex:sender.view.tag]];
    
    
    
    [v1 addSubview:img1];
    
    
    
    
    
    
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.5];
        v1.frame=CGRectMake(150,2*test1*35,200,80);
        [UIView commitAnimations];
    v1.layer.cornerRadius=20;
    v1.layer.borderColor=[[UIColor blueColor]CGColor];
    v1.clipsToBounds=YES;

    //        [v1.layer removeAllAnimations];
    
    
    [self.view addSubview:v1];
    
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return  1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    return [arr count];
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];

cell.imageView.image=[UIImage imageNamed:[arr objectAtIndex:indexPath.row
                 
                                          ]];
    cell.imageView.tag=indexPath.row;
    
    
    
    tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handle:)];
    tap.numberOfTapsRequired=1 ;
    
    
    cell.imageView.userInteractionEnabled=YES;
    
    [cell.imageView  addGestureRecognizer:tap];
    

    
    return cell;
    
}@end
